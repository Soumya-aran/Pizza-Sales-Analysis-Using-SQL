-- Top 3 most oredred pizza type based on revenue

SELECT 
    pizza_types.name, Sum(orders_details.quantity * pizzas.price) AS total_sales
FROM
    pizza_types
        JOIN
    pizzas ON pizza_types.pizza_type_id = pizzas.pizza_type_id
join orders_details 
on  orders_details.pizza_id = pizzas.pizza_id
group by pizza_types.name order by total_sales desc limit 3