-- Top 3 most order pizzas bases on revenue for each category
select name, revenue, Ra_nk from
(select category, name, revenue,
rank() over(partition by category order by revenue desc) as Ra_nk
from
(select pizza_types.category, pizza_types.name , round(sum(orders_details.quantity*pizzas.price),2) as revenue
from pizza_types join pizzas
on pizza_types.pizza_type_id = pizzas.pizza_type_id
join orders_details
on orders_details.pizza_id = pizzas.pizza_id 
group by pizza_types.category, pizza_types.name ) as Sales) as Revenue_rank 
where Ra_nk <= 3 ;